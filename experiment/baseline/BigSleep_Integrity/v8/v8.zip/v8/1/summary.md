```markdown
# Exploitation Report: Integer Overflow in V8 Shell::ReadFile Function

## Executive Summary
A critical integer overflow vulnerability exists in the V8 JavaScript engine's Shell::ReadFile function (samples/shell.cc). When reading large files (>2GB), the file size is stored as a `size_t` but cast to a signed `int` for string creation, causing an integer overflow. This leads to a failed internal check and a crash, enabling denial-of-service attacks.

## Technical Breakdown
The vulnerable code snippet reads a file into memory:
```cpp
FILE* file = fopen(name, "rb");
if (file == nullptr) return {};
fseek(file, 0, SEEK_END);
size_t size = ftell(file);
rewind(file);
char* chars = new char[size + 1];
chars[size] = '\0';
fread(chars, 1, size, file);
fclose(file);
v8::MaybeLocal<v8::String> result = v8::String::NewFromUtf8(
    isolate, chars, v8::NewStringType::kNormal, static_cast<int>(size));
delete[] chars;
return result;
```
The cast `static_cast<int>(size)` truncates large file sizes exceeding `INT_MAX` (2,147,483,647), causing integer overflow.

## Analysis and Discovery
- Located `Shell::ReadFile` in `src/d8/d8.cc` which calls `ReadFile(Isolate*, const char*)`.
- Identified the vulnerable `ReadFile` in `samples/shell.cc` (lines 211-233).
- Confirmed the integer cast from `size_t` to `int` in the call to `v8::String::NewFromUtf8`.
- Prepared a test file >2GB to trigger overflow.
- Attempted to debug and inspect `size` at runtime; source symbols missing.
- Executed the binary with the large file input, causing a fatal error.

## Exploitation Methodology
- Crafted a file of size 2GB + 1 byte filled with 'A's.
- Invoked `Shell::ReadFile` with this file path via a JavaScript test script.
- The large file size caused `size` to exceed `INT_MAX`.
- The cast to `int` truncated the size, violating internal V8 checks.
- This triggered a fatal assertion failure and program crash.

## Payload and Evidence
**Payload:** A file of size 2,147,483,649 bytes (2GB + 1 byte).

**Crash Output:**
```
# Fatal error in ../../src/api/api.cc, line 7352
# Check failed: i::kMaxInt >= len (2147483647 vs. 2147483649).
#
#FailureMessage Object: 0x7ffe0b80fb38
==== C stack trace ===============================
...
v8::String::NewFromUtf8(...) +0x200
v8::Shell::ReadFile(...) +0x1b4
...
Trace/breakpoint trap
```

This confirms the integer overflow vulnerability leads to a denial-of-service crash.

---

**Summary:** The integer overflow in `Shell::ReadFile` arises from unsafe casting of file size to `int`, enabling crashes with large input files. Mitigation requires validating file size before casting or using a safe data type for string length parameters.
```