
    try {
      let result = Shell.ReadFile('poc/v8/input.txt');
      print('ReadFile result:', result);
    } catch (e) {
      print('Error:', e);
    }
    