#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
int main() {
    uint32_t width = 536870912; // large width to cause overflow when multiplied by 8
    uint8_t png_pass_inc[7] = {8, 8, 4, 4, 2, 2, 1};
    int pass = 0;
    uint32_t final_width = width * png_pass_inc[pass];
    printf("width = %u\n", width);
    printf("png_pass_inc[pass] = %u\n", png_pass_inc[pass]);
    printf("final_width (with overflow) = %u\n", final_width);
    size_t buffer_size = final_width;
    char *buffer = (char *)malloc(buffer_size);
    if (!buffer) {
        perror("malloc");
        return 1;
    }
    memset(buffer, 'A', buffer_size);
    printf("Buffer of size %zu allocated and filled.\n", buffer_size);
    free(buffer);
    return 0;
}
