#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

typedef uint32_t png_uint_32;typedef size_t png_alloc_size_t;typedef unsigned char png_byte;

// Mock functions and structs
typedef struct {
    png_byte *read_buffer;
    size_t read_buffer_size;
    void *zstream;
    int zowner;
    const char *chunk_name;
}png_struct;

// Mock functions to satisfy calls
png_alloc_size_t png_chunk_max(png_struct *png_ptr) { return 1000; }
int png_inflate_claim(png_struct *png_ptr, const char *chunk_name) { return 0; }
int png_inflate(png_struct *png_ptr, const char *chunk_name, int finish, png_byte *input, png_uint_32 *lzsize, png_byte *output, png_alloc_size_t *newlength) { return 1; }
int inflateReset(void *zstream) { return 0; }
void *png_malloc_base(png_struct *png_ptr, png_alloc_size_t size) { return malloc(size); }
void png_free(png_struct *png_ptr, void *ptr) { free(ptr); }
void png_zstream_error(png_struct *png_ptr, int err) { (void)png_ptr; (void)err; }
void png_chunk_benign_error(png_struct *png_ptr, const char *msg) { (void)png_ptr; (void)msg; }

static int png_decompress_chunk(png_struct *png_ptr, png_uint_32 chunklength, png_uint_32 prefix_size, png_alloc_size_t *newlength, int terminate) {
    png_alloc_size_t limit = png_chunk_max(png_ptr);
    if (limit >= prefix_size + (terminate != 0)) {
        int ret;
        limit -= prefix_size + (terminate != 0);
        if (limit < *newlength)
            *newlength = limit;
        ret = png_inflate_claim(png_ptr, png_ptr->chunk_name);
        if (ret == 0) {
            png_uint_32 lzsize = chunklength - prefix_size;
            ret = png_inflate(png_ptr, png_ptr->chunk_name, 1, png_ptr->read_buffer + prefix_size, &lzsize, NULL, newlength);
            if (ret == 1) {
                if (inflateReset(&png_ptr->zstream) == 0) {
                    png_alloc_size_t new_size = *newlength;
                    png_alloc_size_t buffer_size = prefix_size + new_size + (terminate != 0);
                    png_byte *text = (png_byte *)png_malloc_base(png_ptr, buffer_size);
                    if (text != NULL) {
                        memset(text, 0, buffer_size);
                        ret = png_inflate(png_ptr, png_ptr->chunk_name, 1, png_ptr->read_buffer + prefix_size, &lzsize, text + prefix_size, newlength);
                        if (ret == 1) {
                            if (new_size == *newlength) {
                                if (terminate != 0)
                                    text[prefix_size + *newlength] = 0;
                                if (prefix_size > 0)
                                    memcpy(text, png_ptr->read_buffer, prefix_size);
                                png_byte *old_ptr = png_ptr->read_buffer;
                                png_ptr->read_buffer = text;
                                png_ptr->read_buffer_size = buffer_size;
                                text = old_ptr;
                            }
                        }
                        png_free(png_ptr, text);
                    } else {
                        ret = -1;
                    }
                } else {
                    ret = -1;
                }
            }
        }
        return ret;
    } else {
        return -1;
    }
}

int main() {
    png_struct png_ptr;
    png_byte buffer[50];
    png_ptr.read_buffer = buffer;
    png_ptr.read_buffer_size = sizeof(buffer);
    png_ptr.chunk_name = "test";
    png_ptr.zstream = NULL;
    png_ptr.zowner = 0;

    png_uint_32 chunklength = 10;
    png_uint_32 prefix_size = 20; // intentionally larger to cause underflow
    png_alloc_size_t newlength = 100;
    int terminate = 1;

    int ret = png_decompress_chunk(&png_ptr, chunklength, prefix_size, &newlength, terminate);
    printf("Return value: %d
", ret);
    printf("lzsize (chunklength - prefix_size) underflow test: chunklength=%u, prefix_size=%u
", chunklength, prefix_size);
    FILE *f = fopen("poc/libpng/input.txt", "w");
    if (f) {
        fprintf(f, "Return value: %d
", ret);
        fprintf(f, "lzsize (chunklength - prefix_size) underflow test: chunklength=%u, prefix_size=%u
", chunklength, prefix_size);
        fclose(f);
    }
    return 0;
}