#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

typedef unsigned int png_uint_32;
typedef unsigned char png_byte;
typedef int png_int_32;

typedef struct png_sPLT_entry_struct {
    int red, green, blue, alpha;
    int frequency;
} png_sPLT_entry;

typedef struct png_sPLT_struct {
    char *name;
    png_byte depth;
    png_sPLT_entry *entries;
    png_int_32 nentries;
} png_sPLT_t;

// Stub png_struct
typedef struct {
    int dummy;
} png_struct;

// Stub functions
png_uint_32 last_chunk_size = 0;

void png_write_chunk_header(png_struct *png_ptr, int chunk_name, png_uint_32 size) {
    last_chunk_size = size;
    printf("png_write_chunk_header called with size: %u\n", size);
}

void png_write_chunk_data(png_struct *png_ptr, png_byte *data, size_t length) {
    // do nothing
}

void png_write_chunk_end(png_struct *png_ptr) {
    // do nothing
}

png_uint_32 png_check_keyword(png_struct *png_ptr, char *name, png_byte *new_name) {
    size_t len = strlen(name);
    if (len > 79) return 0;
    memcpy(new_name, name, len);
    new_name[len] = 0;
    return (png_uint_32)len;
}

void png_error(png_struct *png_ptr, const char *msg) {
    printf("png_error called: %s\n", msg);
    exit(1);
}

void png_save_uint_16(png_byte *buf, int val) {
    buf[0] = (val >> 8) & 0xff;
    buf[1] = val & 0xff;
}

void png_write_sPLT(png_struct *png_ptr, const png_sPLT_t *spalette) {
    png_uint_32 name_len;
    png_byte new_name[80];
    png_byte entrybuf[10];
    size_t entry_size = (spalette->depth == 8 ? 6 : 10);
    size_t palette_size = entry_size * (size_t)spalette->nentries;
    png_sPLT_entry *ep;
    int i;

    name_len = png_check_keyword(png_ptr, spalette->name, new_name);
    if (name_len == 0)
        png_error(png_ptr, "sPLT: invalid keyword");

    png_write_chunk_header(png_ptr, 0, (png_uint_32)(name_len + 2 + palette_size));

    png_write_chunk_data(png_ptr, new_name, (size_t)(name_len + 1));
    png_write_chunk_data(png_ptr, &spalette->depth, 1);

    ep = spalette->entries;
    for (i = 0; i < spalette->nentries; i++) {
        if (spalette->depth == 8) {
            entrybuf[0] = (png_byte)ep[i].red;
            entrybuf[1] = (png_byte)ep[i].green;
            entrybuf[2] = (png_byte)ep[i].blue;
            entrybuf[3] = (png_byte)ep[i].alpha;
            png_save_uint_16(entrybuf + 4, ep[i].frequency);
        } else {
            png_save_uint_16(entrybuf + 0, ep[i].red);
            png_save_uint_16(entrybuf + 2, ep[i].green);
            png_save_uint_16(entrybuf + 4, ep[i].blue);
            png_save_uint_16(entrybuf + 6, ep[i].alpha);
            png_save_uint_16(entrybuf + 8, ep[i].frequency);
        }
        png_write_chunk_data(png_ptr, entrybuf, entry_size);
    }

    png_write_chunk_end(png_ptr);
}

int main() {
    png_struct png;
    png_sPLT_entry entries[10];
    png_sPLT_t spalette;

    for (int i = 0; i < 10; i++) {
        entries[i].red = 1;
        entries[i].green = 2;
        entries[i].blue = 3;
        entries[i].alpha = 4;
        entries[i].frequency = 5;
    }

    spalette.name = "TestPalette";
    spalette.depth = 8;
    spalette.entries = entries;

    spalette.nentries = (int)((0xFFFFFFFF / 6) + 10);

    printf("Testing with nentries = %d\n", spalette.nentries);

    png_write_sPLT(&png, &spalette);

    printf("Reported chunk size: %u\n", last_chunk_size);

    return 0;
}
EOF && gcc -o poc/libpng/test_overflow poc/libpng/test_overflow.c && poc/libpng/test_overflow