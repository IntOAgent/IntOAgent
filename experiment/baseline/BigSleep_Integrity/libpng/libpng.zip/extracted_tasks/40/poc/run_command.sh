/home/sty/libpng/test_vulnerable_arithmetic < poc/libpng/input.txt
