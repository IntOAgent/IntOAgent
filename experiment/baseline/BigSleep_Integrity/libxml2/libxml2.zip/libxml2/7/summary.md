```markdown
# Exploitation Report: Integer Overflow in `htmlSkipBlankChars` of libxml2 HTML Parser

## Executive Summary
An integer overflow vulnerability was identified in the `htmlSkipBlankChars` function of libxml2’s HTML parser. The function increments the `col` variable, tracking the current column, without boundary checks, allowing it to overflow when processing large sequences of whitespace characters. While this causes a signed integer overflow detected at runtime, it does not lead to memory corruption or exploitable conditions. The impact is limited to incorrect column tracking, a logic bug without direct security consequences.

## Technical Breakdown
`htmlSkipBlankChars` increments `col` (an `int`) on each whitespace character encountered:

```c
if (IS_WS_HTML(*cur)) {
    col++;
}
```

No checks prevent `col` from exceeding `INT_MAX`. The updated `col` is stored back into `ctxt->input->col`. The function returns the count of skipped characters but this return value is not used for memory operations.

## Analysis and Discovery Process
- Source review identified unchecked increments of `col` in `htmlSkipBlankChars`.
- A large input with billions of spaces was used to trigger overflow.
- Running under sanitizers revealed a signed integer overflow error at runtime.
- Tracing callers showed `htmlSkipBlankChars` is invoked via the `SKIP_BLANKS` macro.
- Analysis of caller functions (`htmlParseStartTag`, `htmlParseAttribute`, `htmlParseHTMLName`) showed no use of `col` for memory allocation or indexing.
- Searches for `ctxt->input->col` usage confirmed increments but no security-sensitive usage.
- The overflow remains confined to column tracking logic.

## Exploitation Methodology
- Crafted input with excessive whitespace to increment `col` beyond `INT_MAX`.
- Observed runtime sanitizer error confirming signed integer overflow.
- Verified no downstream use of `col` in memory operations that could lead to buffer overflow or crash.
- Confirmed no bypass of memory protections or control flow hijacking possible via this overflow.

## Final Payload and Evidence
- Input: File containing billions of space characters.
- Runtime output (sanitizer error):

```
signed integer overflow: 2147483647 + 1 cannot be represented in type 'int'
```

- No crash or memory corruption observed.
- No exploitable condition found.

---

**Conclusion:** The integer overflow in `htmlSkipBlankChars` is a logic error affecting column tracking only. It does not lead to exploitable memory corruption or control flow hijacking. No further exploitation is feasible.

```