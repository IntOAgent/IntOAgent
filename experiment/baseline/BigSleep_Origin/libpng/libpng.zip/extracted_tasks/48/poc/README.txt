Preparing exploit code in poc/libpng directory
