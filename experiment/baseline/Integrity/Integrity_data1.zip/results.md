## Overall Summary

| Project | Harness(es) | Targets | Reached | Reach Rate | Triggered | Trigger Rate |
|---------|-------------|--------:|--------:|-----------:|----------:|-------------:|
| SQLite `sqlite3.c` | sql + db + shell | 49 | 27 | **55.1%** | 0 | **0.0%** |
| SQLite `shell.c` | shell harness | 35 | 3 | **8.6%** | 0 | **0.0%** |
| libxml2 | xml + html + xpath | 13 | 11 | **84.6%** | 1 | **7.7%** |
| libplist | bplist + xplist + jplist + oplist | 10 | 6 | **60.0%** | 2 | **20.0%** |
| **All (unique targets)** | | **107** | **47** | **43.9%** | **3** | **2.8%** |

### sqlite3.c — 49 unique targets

| Line | Module | Exec Count | Reached | Triggered |
|------|--------|----------:|:-------:|:---------:|
| `sqlite3.c:31365` | `malloc.c` | 116,565 | ✓ | ✗ |
| `sqlite3.c:35572` | `util.c` | 765,911 | ✓ | ✗ |
| `sqlite3.c:94318` | `vdbe.c` | 0 | ✗ | ✗ |
| `sqlite3.c:95338` | `vdbemem.c` | 2,960 | ✓ | ✗ |
| `sqlite3.c:95342` | `vdbemem.c` | 2,960 | ✓ | ✗ |
| `sqlite3.c:97135` | `vdbe.c` | 0 | ✗ | ✗ |
| `sqlite3.c:110487` | `expr.c` | 48,239 | ✓ | ✗ |
| `sqlite3.c:114448` | `insert.c` | 0 | ✗ | ✗ |
| `sqlite3.c:122890` | `build.c` | 60,626 | ✓ | ✗ |
| `sqlite3.c:124233` | `select.c` | 0 | ✗ | ✗ |
| `sqlite3.c:129981` | `func.c` | 3 | ✓ | ✗ |
| `sqlite3.c:131066` | `func.c` | 0 | ✗ | ✗ |
| `sqlite3.c:143519` | `window.c` | 0 | ✗ | ✗ |
| `sqlite3.c:143761` | `window.c` | 0 | ✗ | ✗ |
| `sqlite3.c:143766` | `window.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180246` | `tokenize.c` | 278,928 | ✓ | ✗ |
| `sqlite3.c:180571` | `tokenize.c` | 262,036 | ✓ | ✗ |
| `sqlite3.c:180577` | `tokenize.c` | 64,404 | ✓ | ✗ |
| `sqlite3.c:180612` | `tokenize.c` | 9 | ✓ | ✗ |
| `sqlite3.c:180613` | `tokenize.c` | 2 | ✓ | ✗ |
| `sqlite3.c:180687` | `tokenize.c` | 774,416 | ✓ | ✗ |
| `sqlite3.c:180690` | `tokenize.c` | 1,610 | ✓ | ✗ |
| `sqlite3.c:180698` | `tokenize.c` | 37,339 | ✓ | ✗ |
| `sqlite3.c:180701` | `tokenize.c` | 8,896 | ✓ | ✗ |
| `sqlite3.c:180727` | `tokenize.c` | 453 | ✓ | ✗ |
| `sqlite3.c:180739` | `tokenize.c` | 13,993 | ✓ | ✗ |
| `sqlite3.c:180751` | `tokenize.c` | 11 | ✓ | ✗ |
| `sqlite3.c:180767` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180781` | `tokenize.c` | 94 | ✓ | ✗ |
| `sqlite3.c:180786` | `tokenize.c` | 1 | ✓ | ✗ |
| `sqlite3.c:180801` | `tokenize.c` | 11,126 | ✓ | ✗ |
| `sqlite3.c:180803` | `tokenize.c` | 5,564 | ✓ | ✗ |
| `sqlite3.c:180807` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180810` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180816` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180843` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180846` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180848` | `tokenize.c` | 0 | ✗ | ✗ |
| `sqlite3.c:180878` | `tokenize.c` | 129,732 | ✓ | ✗ |
| `sqlite3.c:180933` | `tokenize.c` | 846,353 | ✓ | ✗ |
| `sqlite3.c:182375` | `malloc.c` | 1,003 | ✓ | ✗ |
| `sqlite3.c:182378` | `malloc.c` | 0 | ✗ | ✗ |
| `sqlite3.c:198932` | `fts3.c` | 0 | ✗ | ✗ |
| `sqlite3.c:202775` | `fts3.c` | 0 | ✗ | ✗ |
| `sqlite3.c:205143` | `fts3.c` | 0 | ✗ | ✗ |
| `sqlite3.c:209755` | `fts3.c` | 0 | ✗ | ✗ |
| `sqlite3.c:243706` | `fts5.c` | 48 | ✓ | ✗ |
| `sqlite3.c:253945` | `fts5.c` | 0 | ✗ | ✗ |
| `sqlite3.c:255949` | `fts5.c` | 0 | ✗ | ✗ |


| Line | Function / Context | Exec Count | Reached | Triggered |
|------|-------------------|----------:|:-------:|:---------:|
| `shell.c:1308` | `local_getline` — buffer realloc | 1,631 | **✓** | ✗ |
| `shell.c:1478` | `ShellText` append realloc | 18 | **✓** | ✗ |
| `shell.c:32506` | `process_input` main loop | 3,380 | **✓** | ✗ |
| `shell.c:1181` | `utf8_width` — text alignment | 0 | ✗ | ✗ |
| `shell.c:1422` | input continuation flag | 0 | ✗ | ✗ |
| `shell.c:1428` | input continuation flag | 0 | ✗ | ✗ |
| `shell.c:1432` | input continuation flag | 0 | ✗ | ✗ |
| `shell.c:4252` | base64 encode helper | 0 | ✗ | ✗ |
| `shell.c:4805` | base64 column output | 0 | ✗ | ✗ |
| `shell.c:5341–5342` | `.import` CSV field counter | 0 | ✗ | ✗ |
| `shell.c:5722` | `.import` ASCII field counter | 0 | ✗ | ✗ |
| `shell.c:6060` | `.output` handler | 0 | ✗ | ✗ |
| `shell.c:6733–6749` | `.separator` handler | 0 | ✗ | ✗ |
| `shell.c:7620–7625` | `.backup` / `.restore` handler | 0 | ✗ | ✗ |
| `shell.c:14455` | `.fts5check` handler | 0 | ✗ | ✗ |
| `shell.c:22034` | `.testctrl` handler | 0 | ✗ | ✗ |
| `shell.c:23232` | error context save | 0 | ✗ | ✗ |
| `shell.c:23983` | output column width | 0 | ✗ | ✗ |
| `shell.c:24223` | column output padding | 0 | ✗ | ✗ |
| `shell.c:25644–25691` | `.open` / `openChrSource` | 0 | ✗ | ✗ |
| `shell.c:26245` | CSV import decoder | 0 | ✗ | ✗ |
| `shell.c:26694` | CSV field reader | 0 | ✗ | ✗ |
| `shell.c:29509` | `.safe` mode handler | 0 | ✗ | ✗ |
| `shell.c:31462` | argument parser | 0 | ✗ | ✗ |
| `shell.c:33124` | `.recover` handler | 0 | ✗ | ✗ |


### Results — 13 unique targets

| Line | Exec Count | Reached | Triggered | Trigger Count | Note |
|------|----------:|:-------:|:---------:|:-------------:|------|
| `HTMLparser.c:457` | 418 | ✓ | ✗ | — | |
| `HTMLparser.c:460` | 37,546 | ✓ | ✗ | — | |
| `HTMLparser.c:2620` | 616,951 | ✓ | ✗ | — | |
| `HTMLparser.c:2720` | 1,376 | ✓ | ✗ | — | |
| `HTMLparser.c:3040` | 800,100 | ✓ | ✗ | — | Near-miss: triggered at :3038 |
| `HTMLparser.c:3053` | 1,341,998 | ✓ | ✗ | — | |
| `HTMLparser.c:3259` | 142,640 | ✓ | ✗ | — | |
| `HTMLparser.c:3483` | 2,990 | ✓ | ✗ | — | |
| `HTMLparser.c:3490` | 0 | ✗ | ✗ | — | Inside `htmlParseScript()` |
| `parser.c:4332` | 0 | ✗ | ✗ | — | Deep entity nesting |
| `parser.c:4548` | 2,194,476 | ✓ | **✓** | **217,126** | `ctxt->sizeentities += ent->length` |
| `parser.c:4551` | 151,866 | ✓ | ✗ | — | |
| `parser.c:4574` | 3,538,197 | ✓ | ✗ | — | |


### Results — 10 unique targets

| Line | Exec Count | Reached | Triggered | Trigger Count | Note |
|------|----------:|:-------:|:---------:|:-------------:|------|
| `base64.c:111` | 10,046,206 | ✓ | **✓** | **168** | OVERFLOW in base64 decode |
| `bplist.c:410` | 344 | ✓ | ✗ | — | |
| `bplist.c:1132` | 0 | ✗ | ✗ | — | Deep nested binary plist |
| `bplist.c:1229` | 0 | ✗ | ✗ | — | Deep nested binary plist |
| `jplist.c:749` | 46,592 | ✓ | **✓** | — | Array index overflow |
| `jplist.c:820` | 9,488 | ✓ | ✗ | — | |
| `oplist.c:767` | 122,734 | ✓ | ✗ | — | Near-miss: triggered at :753 |
| `plistutil.c:232` | 0 | ✗ | ✗ | — | CLI utility not linked |
| `plistutil.c:281` | 0 | ✗ | ✗ | — | CLI utility not linked |
| `xplist.c:1069` | 137,038 | ✓ | ✗ | — | |